jQuery(function($) {
  $(".jqClockPicker").livequery(function() {
    $(this).clockpicker();
  });
});
